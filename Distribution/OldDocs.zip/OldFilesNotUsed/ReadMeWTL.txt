WTL 8.1 build 12085 (3/25/2012)

Changes:

Support for VC++ 11 Beta:
	- DLL version functions are again undefined as they are removed from ATL11
	- AppWizard setup scripts for VC++ 11 and VC++ 11 Express

AppWizard: Added code to default.js to add trailing backslashes to output and intermediate
directories for VS2010 and later

Work for #3485171 - Consolidate _ATL_MIN_CRT specific code in WTL
Implemented common _ATL_MIN_CRT code in MinCrtHelper napespace in atlapp.h
+ moved declaration of WM_MOUSEHWHEEL from atlscrl.h to atlapp.h

atlddx.h: Removed DDX_INDEX for VC6 - it just cannot deal with specialized template functions

atlribbon.h: Fix for x64 warning

Fix for #3424418 - MSG_WM_SYSCOMMAND handler prototype doesn't match.
